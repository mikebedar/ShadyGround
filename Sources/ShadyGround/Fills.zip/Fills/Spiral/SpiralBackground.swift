//
//  SpiralBackground.swift
//  ShadyGround
//
//  Created by Michael Bedar on 9/20/25.
//

import SwiftUI

/// A spiral pattern with customizable frequency, line width, canvas size, and rotation
public struct SpiralBackground: View, PreviewableShaderEffect {
    public let frequency: CGFloat
    public let lineWidth: CGFloat
    public let canvasSize: CGFloat
    public let angle: Double
    public let backgroundColor: Color
    public let foregroundColor: Color

    public init(frequency: CGFloat = 5.0, lineWidth: CGFloat = 0.1, canvasSize: CGFloat = 2.0, angle: Double = 0, backgroundColor: Color = Color.gray.opacity(0.0), foregroundColor: Color = Color.gray.opacity(0.2)) {
        self.frequency = frequency
        self.lineWidth = lineWidth
        self.canvasSize = canvasSize
        self.angle = angle
        self.backgroundColor = backgroundColor
        self.foregroundColor = foregroundColor
    }

    private var shader: Shader {
        SPMShaderLibrary.default.spiral(
            .float(frequency),
            .float(lineWidth),
            .float(canvasSize),
            .float(angle),
            .color(backgroundColor),
            .color(foregroundColor)
        )
    }

    public var body: some View {
        Rectangle()
            .fill(.black)
            .layerEffect(shader, maxSampleOffset: .zero)
    }
}

extension SpiralBackground {
    public static func previewView() -> some View {
        SpiralPreview()
    }
}

@MainActor
private struct SpiralPreview: View {
    @State private var frequency: CGFloat = 5.0
    @State private var lineWidth: CGFloat = 0.1
    @State private var canvasSize: CGFloat = 2.0
    @State private var angle: Double = 0
    @State private var backgroundColor: Color = .gray.opacity(0.0)
    @State private var foregroundColor: Color = .gray.opacity(0.2)
    
    var body: some View {
        VStack(spacing: 0) {
            // Main preview
            SpiralBackground(
                frequency: frequency,
                lineWidth: lineWidth,
                canvasSize: canvasSize,
                angle: angle,
                backgroundColor: backgroundColor,
                foregroundColor: foregroundColor
            )
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .clipped()
            
            // Parameter controls
            VStack(spacing: 16) {
                // Randomize button
                Button(action: randomizeColors) {
                    HStack {
                        Image(systemName: "shuffle")
                        Text("Randomize Colors")
                    }
                    .font(.caption)
                    .foregroundColor(.white)
                    .padding(.horizontal, 12)
                    .padding(.vertical, 6)
                    .background(.blue, in: Capsule())
                }
                
                ParameterControlGrid {
                    NumericParameterControl(
                        title: "Frequency",
                        value: $frequency,
                        in: 0.5...20.0,
                        step: 0.5
                    )
                    
                    NumericParameterControl(
                        title: "Line Width",
                        value: $lineWidth,
                        in: 0.01...0.5,
                        step: 0.01
                    )
                    
                    NumericParameterControl(
                        title: "Canvas Size",
                        value: $canvasSize,
                        in: 0.5...5.0,
                        step: 0.1
                    )
                    
                    AngleParameterControl(
                        title: "Angle",
                        value: $angle
                    )
                    
                    ColorParameterControl(
                        title: "Background Color",
                        value: $backgroundColor
                    )
                    
                    ColorParameterControl(
                        title: "Foreground Color",
                        value: $foregroundColor
                    )
                }
            }
        }
        .onAppear {
            randomizeColors()
        }
    }
    
    private func randomizeColors() {
        let (baseColor, complementaryColor) = ColorUtils.randomColorPair()
        backgroundColor = baseColor
        foregroundColor = complementaryColor
    }
}
